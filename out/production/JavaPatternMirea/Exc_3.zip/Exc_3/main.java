package Exc_3;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

public class main {
    public static void main(String[] args) throws InterruptedException {
//       new ClassOnMap();
        new ClassOnList();
    }
}




